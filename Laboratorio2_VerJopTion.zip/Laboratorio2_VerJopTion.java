package laboratorio2_verjoption;

import javax.swing.JOptionPane;

/**
 *
 * @author Ing.Jhaynner
 */
public class Laboratorio2_VerJopTion {

    public static void main(String[] args) {

        int maxSize = 100;
        String[][] estudiantes = new String[maxSize][8];
        int cantidadEstudiantes = 0;

        while (true) {
            int opcion = Integer.parseInt(JOptionPane.showInputDialog(
                    " (┛◉Д◉)┛彡┻━┻  Menú de opciones  (┛◉Д◉)┛彡┻━┻ \n"
                    + "1. Agregar un estudiante\n"
                    + "2. Mostrar estudiantes ordenados por apellido\n"
                    + "3. Calcular nota definitiva de cada estudiante\n"
                    + "4. Estudiantes con nota definitiva mayor a 4.0\n"
                    + "5. Promedio de nota definitiva por semestre\n"
                    + "6. Estudiantes por encima del promedio por semestre\n"
                    + "7. Promedio global de nota definitiva\n"
                    + "8. Estudiantes por debajo del promedio global\n"
                    + "9. Salir"
            ));

            switch (opcion) {
                case 1:
                    if (cantidadEstudiantes < maxSize) {
                        String codigo = obtenerCodigoEstudiantil();
                        String nombreCompleto = obtenerNombreCompleto();
                        String semestreStr = obtenerSemestre();
                        double[] calificaciones = obtenerCalificaciones();

                        // Guardar la información en la matriz
                        estudiantes[cantidadEstudiantes][0] = codigo;
                        estudiantes[cantidadEstudiantes][1] = nombreCompleto;
                        estudiantes[cantidadEstudiantes][2] = semestreStr;
                        for (int i = 0; i < 5; i++) {
                            estudiantes[cantidadEstudiantes][3 + i] = String.valueOf(calificaciones[i]);
                        }

                        cantidadEstudiantes++;
                    } else {
                        JOptionPane.showMessageDialog(null, "⚠️☠️ El registro de estudiantes está lleno ⚠️☠️");
                    }
                    break;

                case 2:
                    ordenarEstudiantesPorApellido(estudiantes, cantidadEstudiantes);
                    mostrarEstudiantes(estudiantes, cantidadEstudiantes);
                    break;

                case 3:
                    calcularNotaDefinitiva(estudiantes, cantidadEstudiantes);
                    break;

                case 4:
                    estudiantesConNotaMayorA4(estudiantes, cantidadEstudiantes);
                    break;

                case 5:
                    calcularPromedioPorSemestre(estudiantes, cantidadEstudiantes);
                    break;

                case 6:
                    estudiantesPorEncimaDelPromedioPorSemestre(estudiantes, cantidadEstudiantes);
                    break;

                case 7:
                    calcularPromedioGlobal(estudiantes, cantidadEstudiantes);
                    break;

                case 8:
                    estudiantesPorDebajoDelPromedioGlobal(estudiantes, cantidadEstudiantes);
                    break;

                case 9:
                    System.exit(0);
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "⚠️☠️ Opción no válida ⚠️☠️");
                    break;
            }
        }
    }

    private static String obtenerCodigoEstudiantil() {
        String codigo = "";
        while (true) {
            codigo = JOptionPane.showInputDialog("Ingrese el código estudiantil (8 dígitos):");
            if (codigo.length() == 8 && codigo.matches("\\d+")) {
                return codigo;
            } else {
                JOptionPane.showMessageDialog(null, "⚠️ ️Código estudiantil incorrecto ⚠️️ Debe tener 8 dígitos.");
            }
        }
    }

    private static String obtenerNombreCompleto() {
        String nombreCompleto = "";
        String[] nombreSeparado;
        while (true) {
            nombreCompleto = JOptionPane.showInputDialog("Ingrese el nombre completo (Apellido Nombre):");
            nombreSeparado = nombreCompleto.split(" ");
            if (nombreCompleto.length() >= 7 && nombreSeparado.length == 2 && nombreSeparado[0].length() >= 3 && nombreSeparado[1].length() >= 3) {
                return nombreCompleto;
            } else {
                JOptionPane.showMessageDialog(null, "☠ ️Nombre completo incorrecto ☠️ Debe tener al menos 3 caracteres en cada parte (Apellido y Nombre).");
            }
        }
    }

 private static String obtenerSemestre() {
    String semestreStr = "";

    while (true) {
        semestreStr = JOptionPane.showInputDialog("Ingrese el semestre en curso (1-12):");
        try {
            int semestre = Integer.parseInt(semestreStr);
            if (semestre >= 1 && semestre <= 12) {
                return semestreStr; // Devolvemos el valor del semestre como una cadena de texto
            } else {
                JOptionPane.showMessageDialog(null, "⚠️ Semestre incorrecto ⚠️ Debe ser un número entre 1 y 12.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "⚠️ Semestre incorrecto ⚠️️ Debe ser un número entre 1 y 12.");
        }
    }
}


    private static double[] obtenerCalificaciones() {
        double[] calificaciones = new double[5];
        for (int i = 0; i < 5; i++) {
            String notaStr = "";
            double nota = 0.0;
            while (true) {
                notaStr = JOptionPane.showInputDialog("Ingrese la calificación N" + (i + 1) + " (0.0 - 5.0):");
                try {
                    nota = Double.parseDouble(notaStr);
                    if (notaStr.matches("^\\d+(\\.\\d{1,2})?$") && nota >= 0.0 && nota <= 5.0) {
                        calificaciones[i] = nota;
                        break;
                    } else {
                        JOptionPane.showMessageDialog(null, "☠️Calificación incorrecta ☠️ Debe estar en el rango de 0.0 a 5.0.");
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "️☠ ️Calificación incorrecta ☠️ Debe estar en el rango de 0.0 a 5.0.");
                }
            }
        }
        return calificaciones;
    }

    private static void ordenarEstudiantesPorApellido(String[][] estudiantes, int cantidadEstudiantes) {
        for (int i = 0; i < cantidadEstudiantes - 1; i++) {
            for (int j = i + 1; j < cantidadEstudiantes; j++) {
                if (estudiantes[i][1].compareTo(estudiantes[j][1]) > 0) {
                    String[] temp = estudiantes[i];
                    estudiantes[i] = estudiantes[j];
                    estudiantes[j] = temp;
                }
            }
        }
    }

    private static void calcularNotaDefinitiva(String[][] estudiantes, int cantidadEstudiantes) {
        for (int i = 0; i < cantidadEstudiantes; i++) {
            double sumaNotas = 0.0;
            for (int j = 0; j < 5; j++) {
                sumaNotas += Double.parseDouble(estudiantes[i][3 + j]);
            }
            double notaDefinitiva = sumaNotas / 5;
            estudiantes[i][8] = String.format("%.2f", notaDefinitiva);
        }
        JOptionPane.showMessageDialog(null, "Notas definitivas calculadas y almacenadas.");
    }

    private static void estudiantesConNotaMayorA4(String[][] estudiantes, int cantidadEstudiantes) {
        StringBuilder estudiantesAprobados = new StringBuilder("Estudiantes con nota definitiva mayor a 4.0:\n");
        for (int i = 0; i < cantidadEstudiantes; i++) {
            double notaDefinitiva = Double.parseDouble(estudiantes[i][8]);
            if (notaDefinitiva > 4.0) {
                estudiantesAprobados.append(estudiantes[i][1] + " " + estudiantes[i][2] + " (Nota Definitiva: " + notaDefinitiva + ")\n");
            }
        }
        JOptionPane.showMessageDialog(null, estudiantesAprobados.toString());
    }

    private static void calcularPromedioPorSemestre(String[][] estudiantes, int cantidadEstudiantes) {
        double[] promedioSemestres = new double[12];
        int[] contadorSemestres = new int[12];

        for (int i = 0; i < cantidadEstudiantes; i++) {
            int semestre = Integer.parseInt(estudiantes[i][2]);
            double notaDefinitiva = Double.parseDouble(estudiantes[i][8]);
            promedioSemestres[semestre - 1] += notaDefinitiva;
            contadorSemestres[semestre - 1]++;
        }

        StringBuilder promedios = new StringBuilder("Promedio de nota definitiva por semestre:\n");
        for (int i = 0; i < 12; i++) {
            if (contadorSemestres[i] > 0) {
                promedioSemestres[i] /= contadorSemestres[i];
                promedios.append("Semestre " + (i + 1) + ": " + String.format("%.2f", promedioSemestres[i]) + "\n");
            }
        }
        JOptionPane.showMessageDialog(null, promedios.toString());
    }

    private static void estudiantesPorEncimaDelPromedioPorSemestre(String[][] estudiantes, int cantidadEstudiantes) {
        double[] promedioSemestres = new double[12];
        int[] contadorSemestres = new int[12];

        for (int i = 0; i < cantidadEstudiantes; i++) {
            int semestre = Integer.parseInt(estudiantes[i][2]);
            double notaDefinitiva = Double.parseDouble(estudiantes[i][8]);
            promedioSemestres[semestre - 1] += notaDefinitiva;
            contadorSemestres[semestre - 1]++;
        }

        StringBuilder estudiantesPorEncimaDelPromedio = new StringBuilder("Estudiantes por encima del promedio por semestre:\n");
        for (int i = 0; i < cantidadEstudiantes; i++) {
            int semestre = Integer.parseInt(estudiantes[i][2]);
            double notaDefinitiva = Double.parseDouble(estudiantes[i][8]);
            double promedio = promedioSemestres[semestre - 1] / contadorSemestres[semestre - 1];
            if (notaDefinitiva > promedio) {
                estudiantesPorEncimaDelPromedio.append(estudiantes[i][1] + " " + estudiantes[i][2] + " (Semestre " + semestre + " - Nota Definitiva: " + notaDefinitiva + ")\n");
            }
        }
        JOptionPane.showMessageDialog(null, estudiantesPorEncimaDelPromedio.toString());
    }

    private static void calcularPromedioGlobal(String[][] estudiantes, int cantidadEstudiantes) {
        double sumaNotas = 0.0;
        for (int i = 0; i < cantidadEstudiantes; i++) {
            double notaDefinitiva = Double.parseDouble(estudiantes[i][8]);
            sumaNotas += notaDefinitiva;
        }
        double promedioGlobal = sumaNotas / cantidadEstudiantes;

        JOptionPane.showMessageDialog(null, "Promedio global de nota definitiva: " + String.format("%.2f", promedioGlobal));
    }

    private static void estudiantesPorDebajoDelPromedioGlobal(String[][] estudiantes, int cantidadEstudiantes) {
        double sumaNotas = 0.0;
        for (int i = 0; i < cantidadEstudiantes; i++) {
            double notaDefinitiva = Double.parseDouble(estudiantes[i][8]);
            sumaNotas += notaDefinitiva;
        }
        double promedioGlobal = sumaNotas / cantidadEstudiantes;

        StringBuilder estudiantesPorDebajoDelPromedio = new StringBuilder("Estudiantes por debajo del promedio global:\n");
        for (int i = 0; i < cantidadEstudiantes; i++) {
            double notaDefinitiva = Double.parseDouble(estudiantes[i][8]);
            if (notaDefinitiva < promedioGlobal) {
                estudiantesPorDebajoDelPromedio.append(estudiantes[i][1] + " " + estudiantes[i][2] + " (Nota Definitiva: " + notaDefinitiva + ")\n");
            }
        }
        JOptionPane.showMessageDialog(null, estudiantesPorDebajoDelPromedio.toString());
    }

    private static void mostrarEstudiantes(String[][] estudiantes, int cantidadEstudiantes) {
        StringBuilder reporte = new StringBuilder("Registro de Estudiantes de Ciencias de la Salud:\n");
        for (int i = 0; i < cantidadEstudiantes; i++) {
            reporte.append("Estudiante " + (i + 1) + ":\n");
            reporte.append("Código Estudiantil: " + estudiantes[i][0] + "\n");
            reporte.append("Nombre Completo: " + estudiantes[i][1] + " " + estudiantes[i][2] + "\n");
            reporte.append("Semestre en Curso: " + estudiantes[i][3] + "\n");
            reporte.append("Calificaciones:\n");
            for (int j = 0; j < 5; j++) {
                reporte.append("N" + (j + 1) + ": " + estudiantes[i][3 + j] + "\n");
            }
            reporte.append("\n");
        }
        JOptionPane.showMessageDialog(null, reporte.toString());
    }
}


//Profe! nos merecemos el 5 (┛◉Д◉)┛彡┻━┻, un dia mas sin dormir,seria lo mas justo 👍